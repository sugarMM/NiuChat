package com.service;

import com.common.Message;
import com.common.MessageType;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.Socket;

/**
 * 客户端和服务器端保持通信线程类
 */
public class ClientConnectServerThread implements Runnable {
    //该线程需要持有Socket
    private Socket socket;

    //构造器接收一个Socket对象
    public ClientConnectServerThread(Socket socket) {
        this.socket = socket;
    }

    public Socket getSocket() {
        return socket;
    }

    /**
     * 该线程需要在后台和服务器保持通信
     */
    @Override
    public void run() {
        while (true) {
            System.out.println("客户端线程等待读取从服务器端发送的消息");

            try {
                ObjectInputStream objectInputStream = new ObjectInputStream(socket.getInputStream());
                //当没有数据传输，线程阻塞在此处
                Message message = (Message) objectInputStream.readObject();
                // TODO: 2022-04-19 使用message和退出线程的条件
                //判断接收到的数据类型
                if (message.getMesType().equals(MessageType.MESSAGE_RET_ONLINE_FRIENDS)) {
                    //取出在线列表信息，并显示 内容格式：100 200 300 ...
                    String[] onlineUsers = message.getContent().split(" ");
                    System.out.println("===========当前在线用户列表=============");
                    for (String user :
                            onlineUsers) {
                        System.out.println("用户：" + user);
                    }
                } else if (message.getMesType().equals(MessageType.MESSAGE_COMM_MES)) {
                    //接收到私信消息，在控制台进行显示
                    System.out.println("\n" + message.getSendTime() + "\n" + message.getSender() + " 对 你" + " 说: " + message.getContent());
                } else if (message.getMesType().equals(MessageType.MESSAGE_TO_ALL_MES)) {
                    //接收到所有人消息，在控制台进行显示
                    System.out.println("\n" + message.getSendTime() + "\n" + message.getSender() + " 对 大家 说: " + message.getContent());
                } else if (message.getMesType().equals(MessageType.MESSAGE_FILE_MES)) {
                    //接收到文件消息
                    System.out.println("\n" + message.getSendTime() + "\n" + message.getSender() + " 给 你 发送文件: " + message.getSrc() + " 到此电脑的 " + message.getDest() + " 路径下");
                    //写入磁盘
                    FileOutputStream fileOutputStream = new FileOutputStream(message.getDest());
                    fileOutputStream.write(message.getFileBytes());
                    //关闭IO流
                    fileOutputStream.close();
                    System.out.println("文件保存成功！");
                } else {
                    System.out.println("其他类型Message");
                }


            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }


}
