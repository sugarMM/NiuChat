package com.service;

import java.util.HashMap;

/**
 * 管理客户端连接服务器端线程的类
 * 一个用户Id一个线程
 * 线程使用Runnable实现，用Thread.start()调用，因此实际上管理的是对象，服务器端的方式是管理线程
 */
public class ManageClientConnectServerThread {
    //把多个线程放入HashMap中，key = 用户ID  value = 线程
    private static HashMap<String, ClientConnectServerThread> hashMap = new HashMap<>();

    /**
     * 将用户线程加入管理集合
     *
     * @param userId                    用户id
     * @param clientConnectServerThread 线程
     */
    public static void addClientConnectServerThread(String userId, ClientConnectServerThread clientConnectServerThread) {
        hashMap.put(userId, clientConnectServerThread);
    }

    /**
     * 获取用户id对应线程
     *
     * @param userId 用户id
     * @return 对应线程
     */
    public static ClientConnectServerThread getClientConnectServerThread(String userId) {
        return hashMap.get(userId);
    }

}
