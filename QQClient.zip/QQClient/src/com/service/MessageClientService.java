package com.service;

import com.common.Message;
import com.common.MessageType;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Date;

/**
 * 该类提供和消息相关的服务方法
 */
public class MessageClientService {
    /**
     * 发送消息给其他用户
     *
     * @param senderId   发送用户Id
     * @param receiverId 接收用户Id
     * @param content    内容
     */
    public void sendMessageToOne(String senderId, String receiverId, String content) {
        //构建Message对象
        Message message = new Message();
        message.setMesType(MessageType.MESSAGE_COMM_MES);
        message.setSender(senderId);
        message.setReceiver(receiverId);
        message.setContent(content);
        message.setSendTime(new Date().toString());
        System.out.println("我 对 " + receiverId + " 说： " + content);
        //发送给服务端
        try {
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(ManageClientConnectServerThread.getClientConnectServerThread(senderId).getSocket().getOutputStream());
            objectOutputStream.writeObject(message);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 发送消息给所有人
     *
     * @param senderId 发送人
     * @param content  内容
     */
    public void sendMessageToAll(String senderId, String content) {
        Message message = new Message();
        message.setMesType(MessageType.MESSAGE_TO_ALL_MES);
        message.setSender(senderId);
        message.setContent(content);
        message.setSendTime(new Date().toString());
        System.out.println("我 对 大家 说： " + content);
        try {
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(ManageClientConnectServerThread.getClientConnectServerThread(senderId).getSocket().getOutputStream());
            objectOutputStream.writeObject(message);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}
