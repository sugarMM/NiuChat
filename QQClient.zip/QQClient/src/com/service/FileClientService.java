package com.service;

import com.common.Message;
import com.common.MessageType;

import java.io.*;
import java.util.Date;

/**
 * 该类完成文件传输服务
 */
public class FileClientService {
    /**
     * 发送文件消息给其他用户
     *
     * @param src      源文件地址
     * @param dest     文件存放目标路径
     * @param sender   用户Id
     * @param receiver 接收用户Id
     */
    public void sendFileToOne(String src, String dest, String sender, String receiver) {
        //读取src文件，包装成Message对象
        Message message = new Message();
        message.setMesType(MessageType.MESSAGE_FILE_MES);
        message.setSender(sender);
        message.setReceiver(receiver);
        message.setSrc(src);
        message.setDest(dest);
        message.setSendTime(new Date().toString());
        //将文件读取
        FileInputStream fileInputStream = null;
        byte[] fileByte = new byte[(int) new File(src).length()];
        try {
            fileInputStream = new FileInputStream(src);
            fileInputStream.read(fileByte);//将src文件读入程序的字节数组
            //将字节数组放入message对象
            message.setFileBytes(fileByte);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            //关闭IO流
            if (fileInputStream != null)
                try {
                    fileInputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
        }
        System.out.println("\n" + message.getSender() + " 给 " + message.getReceiver() + " 发送文件：" + message.getSrc() + " 到对方的电脑目录： " + dest);
        //发送
        try {
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(ManageClientConnectServerThread.getClientConnectServerThread(message.getSender()).getSocket().getOutputStream());
            objectOutputStream.writeObject(message);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
