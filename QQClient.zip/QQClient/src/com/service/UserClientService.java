package com.service;

import com.common.Message;
import com.common.MessageType;
import com.common.User;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;

/**
 * 完成用户登录验证、注册等功能
 */
public class UserClientService {
    private User user = new User(); //可能在其他地方使用User信息，因此做为成员属性
    private Socket socket; //作为线程使用，因此需要定义为成员属性

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    /**
     * 到服务器验证用户信息是否有效
     * 过程为客户端将用户名密码打包成一个user对象，服务器端通过解析对象属性判断是否通过验证
     * 将验证结果打包成Message对象发送给客户端
     *
     * @param userId 用户ID
     * @param passwd 用户密码
     * @return 是否通过验证
     */
    public boolean checkUser(String userId, String passwd) {
        boolean bool = false;
        user.setUserId(userId);
        user.setPasswd(passwd);
        //连接到服务器端，发送user对象
        try {
            socket = new Socket(InetAddress.getByName("127.0.0.1"), 9999);
            //得到ObjectOutputStream对象
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(socket.getOutputStream());
            //发送user对象
            objectOutputStream.writeObject(user);
            //获取Message对象
            ObjectInputStream objectInputStream = new ObjectInputStream(socket.getInputStream());
            Message message = (Message) objectInputStream.readObject();
            //判断是否验证通过
            if (message.getMesType().equals(MessageType.MESSAGE_LOGIN_SUCCEED)) {
                bool = true;
                //创建一个和服务器端通信的线程
                ClientConnectServerThread clientConnectServerThread = new ClientConnectServerThread(socket);
                Thread Thread = new Thread(clientConnectServerThread);
                Thread.start(); //Thread不能强转成ClientConnectServerThread
                //为了建立一台机器建立多个线程与服务器通信，将线程加入线程集合管理
                ManageClientConnectServerThread.addClientConnectServerThread(userId, clientConnectServerThread);

            } else {
                //登录失败需要关闭socket
                socket.close();
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return bool;
    }

    /**
     * 获取在线用户列表
     */
    public void onLineFriendsList() {
        //发送一个Message，类型为MESSAGE_GET_ONLINE_FRIENDS
        Message message = new Message();
        message.setMesType(MessageType.MESSAGE_GET_ONLINE_FRIENDS);
        message.setSender(user.getUserId());
        //发送给服务器
        try {
            //得到当前线程的Socket对应的IO对象
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(ManageClientConnectServerThread.getClientConnectServerThread(user.getUserId()).getSocket().getOutputStream());
            objectOutputStream.writeObject(message);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 退出系统，并给服务器发送Message对象
     */
    public void logout() {
        //创建message对象
        Message message = new Message();
        message.setMesType(MessageType.MESSAGE_CLIENT_EXIT);
        message.setSender(user.getUserId());//指定那个客户端要退出
        //发送Message
        try {
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(socket.getOutputStream()); //与onLineFriendsList中的写法均可
            objectOutputStream.writeObject(message);
            System.out.println(user.getUserId() + "退出系统");
            System.exit(0); //结束程序
        } catch (IOException e) {
            e.printStackTrace();

        }
    }

}
