package com.view;

import com.Utils.Utility;
import com.service.FileClientService;
import com.service.MessageClientService;
import com.service.UserClientService;

/**
 * 客户端的菜单界面
 */
@SuppressWarnings({"all"})
public class View {
    private boolean loop = true;//控制是否显示菜单
    private String key; //接收用户输入
    private UserClientService userClientService = new UserClientService();//用于登录服务/注册用户

    //显示主菜单
    private void mainMenu() {
        while (loop) {
            System.out.println("=========欢迎登录网络通信系统===========");
            System.out.println("          1.登录系统");
            System.out.println("          9.退出系统");
            System.out.print("请输入你的选择：");
            key = Utility.readString(1);
            switch (key) {
                case "1":
                    System.out.print("请输入用户号：");
                    String userId = Utility.readString(50);
                    System.out.print("请输入密  码：");
                    String passwd = Utility.readString(50);
                    // 需要到服务器验证该用户是否合法
                    if (userClientService.checkUser(userId, passwd)) {
                        while (loop) {
                            System.out.println("=========网络通信系统二级菜单(用户" + userId + ")===========");
                            //进入二级菜单
                            System.out.println("          1.显示在线用户列表");
                            System.out.println("          2.群发消息");
                            System.out.println("          3.私聊消息");
                            System.out.println("          4.发送文件");
                            System.out.println("          9.退出系统");
                            System.out.print("请输入你的选择：");
                            key = Utility.readString(1);
                            switch (key) {
                                case "1":
                                    System.out.println("显示在线用户列表");
                                    userClientService.onLineFriendsList();
                                    break;
                                case "2":
                                    System.out.print("请输入群发消息：");
                                    String content1 = Utility.readString(100);
                                    //将内容封装到message发送给服务器端
                                    new MessageClientService().sendMessageToAll(userId, content1);
                                    break;
                                case "3":
                                    System.out.print("请输入想聊天的用户号(在线):");
                                    String receiverId = Utility.readString(50);
                                    System.out.print("请输入想发送的信息:");
                                    String content2 = Utility.readString(100);
                                    //发送给服务器端
                                    new MessageClientService().sendMessageToOne(userId, receiverId, content2);
                                    break;
                                case "4":
                                    System.out.print("请输入想发送文件的用户号(在线):");
                                    //new FileClientService().sendFileToOne("src//mimi.jpg", "src//mimi2.jpg", userId, Utility.readString(50));
                                    String fileReceiverId = Utility.readString(50);
                                    System.out.print("请输入发送的文件目录(形式如[src//mimi.png]):");
                                    String src = Utility.readString(100);
                                    System.out.print("请输入存储的文件地址(形式如[E://mimi.png]):");
                                    String dest = Utility.readString(100);
                                    //调用文件发送方法，发送给服务器端
                                    new FileClientService().sendFileToOne(src, dest, userId, fileReceiverId);
                                    break;
                                case "9": //退出系统
                                    userClientService.logout();
                                    loop = false;
                                    break;
                            }
                            //避免二级菜单输出过快，浅睡一下
                            try {
                                Thread.sleep(1000);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                    } else {
                        //登陆失败
                        System.out.println("用户名密码错误，登陆失败！");
                    }
                    break;
                case "9": //退出系统
                    loop = false;
                    break;
            }
        }
        System.out.println("客户端退出系统！");
//        System.exit(0); //结束程序
    }

    public static void main(String[] args) {
        new View().mainMenu();
    }
}
