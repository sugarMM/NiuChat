package com.frame;

import com.service.Server;

/**
 * 启动服务器服务
 */
public class Frame {
    public static void main(String[] args) {

        new Server();
    }
}
