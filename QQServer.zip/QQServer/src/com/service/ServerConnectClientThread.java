package com.service;

import com.common.Message;
import com.common.MessageType;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 服务器端连接客户端的线程类
 */
public class ServerConnectClientThread extends Thread {
    private Socket socket; //客户端连接的socket对象
    private String userId; //客户Id

    public ServerConnectClientThread(Socket socket, String userId) {
        this.socket = socket;
        this.userId = userId;
    }

    public Socket getSocket() {
        return socket;
    }

    @Override
    public void run() {
        there:
        while (true) {
            System.out.println("服务器端和" + userId + "客户端保持桃心，读取数据...");
            try {
                ObjectInputStream objectInputStream = new ObjectInputStream(socket.getInputStream());
                Message message = (Message) objectInputStream.readObject();
                //判断message类型，并进行处理
                switch (message.getMesType()) {
                    case MessageType.MESSAGE_GET_ONLINE_FRIENDS: //获取在线用户列表
                        System.out.println(message.getSender() + "需要获取在线用户列表");
                        //用户列表保存在线程管理集合中，每个线程有userId，输出内容格式为100 200 300 ...
                        String onlineUserList = ManageServerConnectClientThread.getOnlineUserList();
                        //返回信息，构建Message对象
                        Message message2 = new Message();
                        message2.setMesType(MessageType.MESSAGE_RET_ONLINE_FRIENDS);
                        message2.setContent(onlineUserList);
                        message2.setReceiver(message.getSender());
                        //创建返回信息的IO流
                        ObjectOutputStream objectOutputStream = new ObjectOutputStream(socket.getOutputStream());
                        //写入socket，返回数据
                        objectOutputStream.writeObject(message2);
                        break;
                    case MessageType.MESSAGE_COMM_MES://私聊消息
                        //根据message获取receiver的Id，然后得到对应线程
                        ServerConnectClientThread serverConnectClientThread1 = null;
                        ObjectOutputStream objectOutputStream1 = null;
                        try {
                            //查看接收用户是否存在，不存在抛出空指针异常
                            Server.getValidUsers().get(message.getReceiver()).equals("");
                            //判断用户是否在线
                            if (ManageServerConnectClientThread.getServerConnectClientThread(message.getReceiver()) != null) { //接收用户在线
                                serverConnectClientThread1 = ManageServerConnectClientThread.getServerConnectClientThread(message.getReceiver());
                                //获得对应线程的输出流
                                objectOutputStream1 = new ObjectOutputStream(serverConnectClientThread1.getSocket().getOutputStream());//.socket 也可以
                                //转发消息
                                objectOutputStream1.writeObject(message);
                            } else { //接收用户不在线
                                // TODO: 2022-04-23 如果客户不在线可以存入数据库做离线消息(现在存入的是stringArrayListHashMap)
                                if (Server.getOffLineDb().get(message.getReceiver()) != null) { //当前用户有未读的离线消息
                                    //将消息放入离线消息集合
                                    Server.getOffLineDb().get(message.getReceiver()).add(message);
                                } else {
                                    //创建一个链表存放message
                                    ArrayList<Message> mes = new ArrayList<>();
                                    mes.add(message);
                                    //将接受用户和消息放入离线消息集合
                                    Server.addOffLineDb(message.getReceiver(), mes);
                                }
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        } catch (NullPointerException e) {
                            //用户不存在，返回无法发送消息对象
                            serverConnectClientThread1 = ManageServerConnectClientThread.getServerConnectClientThread(message.getSender());
                            message.setContent("用户号不存在");
                            message.setSender("服务器");
                            message.setSendTime(new Date().toString());
                            //获取输出流，输出消息
                            objectOutputStream1 = new ObjectOutputStream(serverConnectClientThread1.getSocket().getOutputStream());
                            objectOutputStream1.writeObject(message);
                        }


                        break;

                    case MessageType.MESSAGE_TO_ALL_MES://群发消息
                        ServerConnectClientThread serverConnectClientThread2 = null;
                        ObjectOutputStream objectOutputStream2 = null;
                        //遍历ManageServerConnectClientThread的HashMap获得key，排除发送人，然后发送消息
                        for (String uid : ManageServerConnectClientThread.getHashMap().keySet()) {
                            if (!message.getSender().equals(uid)) {//排除发送人
                                serverConnectClientThread2 = ManageServerConnectClientThread.getServerConnectClientThread(uid);
                                //获得对应线程的输出流
                                objectOutputStream2 = new ObjectOutputStream(serverConnectClientThread2.socket.getOutputStream());
                                //转发消息
                                objectOutputStream2.writeObject(message);
                            }
                        }

                        break;
                    case MessageType.MESSAGE_FILE_MES://文件消息
                        //根据message获取receiver的Id，然后得到对应线程
                        ServerConnectClientThread serverConnectClientThread3 = ManageServerConnectClientThread.getServerConnectClientThread(message.getReceiver());
                        ObjectOutputStream objectOutputStream3 = null;
                        // TODO: 2022-04-23 接收方去指定文件存储路径
                        try {
                            objectOutputStream3 = new ObjectOutputStream(serverConnectClientThread3.getSocket().getOutputStream());
                            objectOutputStream3.writeObject(message);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                        break;
                    case MessageType.MESSAGE_CLIENT_EXIT://客户端退出
                        System.out.println(message.getSender() + " 退出");
                        //将线程从集合中移除
                        ManageServerConnectClientThread.removeServerConnectClientThread(message.getSender());
                        socket.close();//关闭连接
                        break there;
                }
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }

        }
    }
}
