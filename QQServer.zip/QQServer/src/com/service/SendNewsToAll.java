package com.service;

import com.Utils.Utility;
import com.common.Message;
import com.common.MessageType;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Date;
import java.util.HashMap;

/**
 * 该类为服务器推送新闻给所有人
 */
public class SendNewsToAll implements Runnable {

    @Override
    public void run() {
        //实现多次推送
        while (true) {
            System.out.print("请输入服务器要推送的消息[输入exit退出推送服务]:");
            String news = Utility.readString(100);
            //退出推送线程
            if ("exit".equals(news)) {
                System.out.println("推送服务已退出");
                break;
            }
            //创建信息
            Message message = new Message();
            //本质还是群发消息
            message.setMesType(MessageType.MESSAGE_TO_ALL_MES);
            message.setSender("服务器");
            message.setContent(news);
            message.setSendTime(new Date().toString());
            System.out.println("服务器 推送消息给 所有人 ：" + news);
            //获取所有在线用户列表
            HashMap<String, ServerConnectClientThread> hashMap = ManageServerConnectClientThread.getHashMap();
            ObjectOutputStream objectOutputStream = null;
            for (String uid : hashMap.keySet()) {
                try {
                    //推送消息
                    objectOutputStream = new ObjectOutputStream(hashMap.get(uid).getSocket().getOutputStream());
                    objectOutputStream.writeObject(message);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
