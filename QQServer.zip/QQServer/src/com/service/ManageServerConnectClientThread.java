package com.service;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

/**
 * 管理服务器端连接客户端的线程集合
 * 客户端和服务器端的线程实现方式不同，需要注意
 */
public class ManageServerConnectClientThread {
    private static HashMap<String, ServerConnectClientThread> hashMap = new HashMap<>();

    public static HashMap<String, ServerConnectClientThread> getHashMap() {
        return hashMap;
    }

    /**
     * 添加线程对象到集合
     *
     * @param userId                    用户Id
     * @param serverConnectClientThread 对应线程
     */
    public static void addServerConnectClientThread(String userId, ServerConnectClientThread serverConnectClientThread) {
        hashMap.put(userId, serverConnectClientThread);
    }

    /**
     * 根据用户Id获取线程
     *
     * @param userId 用户Id
     * @return 用户线程(其实是对象)
     */
    public static ServerConnectClientThread getServerConnectClientThread(String userId) {
        return hashMap.get(userId);
    }

    public static String getOnlineUserList() {
        StringBuilder onlineUserList = new StringBuilder();
        //遍历HashMap的key，获取单个线程的userId
        Iterator<String> iterator = hashMap.keySet().iterator();
        while (iterator.hasNext()) {
            onlineUserList.append(iterator.next().toString()).append(" ");
        }

        return onlineUserList.toString();
    }

    /**
     * 用户退出后移除当前用户线程
     * @param userId 用户Id
     */
    public static void removeServerConnectClientThread(String userId) {
        hashMap.remove(userId);
    }
}
