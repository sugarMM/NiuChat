package com.service;

import com.common.Message;
import com.common.MessageType;
import com.common.User;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 服务器类，监听9999号端口，等待客户端连接，并保持通信
 */
public class Server {
    private ServerSocket serverSocket = null;
    // TODO: 2022-04-20 暂时使用HashMap保存用户id密码，后续使用数据库保存
    private static ConcurrentHashMap<String, User> validUsers = new ConcurrentHashMap<>();//保存用户的集合,ConcurrentHashMap可以在并发条件下
    private static ConcurrentHashMap<String, ArrayList<Message>> offLineDb = new ConcurrentHashMap<>();//保存发送给未在线对象的消息

    //初始化validUsers
    static {
        validUsers.put("100", new User("100", "123456"));
        validUsers.put("200", new User("200", "123456"));
        validUsers.put("300", new User("300", "123456"));
        validUsers.put("400", new User("400", "123456"));
    }

    public Server() {
        System.out.println("服务器端9999端口监听");
        Thread thread = new Thread(new SendNewsToAll());
        thread.start();

        try {
            serverSocket = new ServerSocket(9999);
            //当和某个客户端建立连接后，应该继续保持监听
            while (true) {
                Socket socket = serverSocket.accept();
                //得到socket关联的对象输入流
                ObjectInputStream objectInputStream = new ObjectInputStream(socket.getInputStream());
                //获取客户端发送的User对象
                User user = (User) objectInputStream.readObject();
                //创建Message对象和输出IO流，准备回复客户端
                Message message = new Message();
                ObjectOutputStream objectOutputStream = new ObjectOutputStream(socket.getOutputStream());
                //验证用户名密码
                if (checkUser(user.getUserId(), user.getPasswd())) {
                    //验证通过
                    message.setMesType(MessageType.MESSAGE_LOGIN_SUCCEED);
                    //创建线程和客户端保持通信，该线程需要持有socket对象
                    ServerConnectClientThread serverConnectClientThread = new ServerConnectClientThread(socket, user.getUserId());
                    serverConnectClientThread.start();
                    //将该线程对象放入集合中管理
                    ManageServerConnectClientThread.addServerConnectClientThread(user.getUserId(), serverConnectClientThread);
                    //回复成功消息
                    objectOutputStream.writeObject(message);
                    //将未在线时收到的消息发送给登录用户
                    if (offLineDb.get(user.getUserId()) != null) {
                        for (Message offOnlineMessage : offLineDb.get(user.getUserId())) {
                            //转发消息
                            // TODO: 2022-04-24 其实可以不用新new，但是需要每次写入对oos处理，因为每次写入都会默认加入一个header信息，加入时清空再写入obj就可以
                            new ObjectOutputStream(socket.getOutputStream()).writeObject(offOnlineMessage);
                        }
                        offLineDb.remove(user.getUserId());
                    }


                } else {
                    //验证失败，回复消息
                    message.setMesType(MessageType.MESSAGE_LOGIN_FAILURE);
                    objectOutputStream.writeObject(message);
                    //需要关闭当前socket
                    socket.close();
                }

            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            //如果服务端退出while，则说明服务器端不再监听，关闭serverSocket
            try {
                serverSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 检查用户名密码是否存在
     *
     * @param userId 用户id
     * @param passwd 密码
     * @return 是否通过验证
     */
    public boolean checkUser(String userId, String passwd) {
        // TODO: 2022-04-20 用户名不在集合内空指针异常
        return validUsers.get(userId).getPasswd().equals(passwd);
    }

    public static ConcurrentHashMap<String, ArrayList<Message>> getOffLineDb() {
        return offLineDb;
    }

    public static ConcurrentHashMap<String, User> getValidUsers() {
        return validUsers;
    }

    /**
     * 将接收用户的离线消息添加到离线集合中
     * @param receiverId 接收用户Id
     * @param messages 离线消息
     */
    public static void addOffLineDb(String receiverId, ArrayList<Message> messages) {
        offLineDb.put(receiverId, messages);
    }



}
